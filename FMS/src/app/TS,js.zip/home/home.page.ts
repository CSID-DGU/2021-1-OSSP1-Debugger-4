import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from "@angular/common/http";
import { LoadingPage } from '../loading/loading.page';
import { FinalPage } from '../final/final.page';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})

export class HomePage {
private file: File;
private file2: File;
  constructor(
    private http: HttpClient,
    private router: Router)
  {

  }


  navigateToLoading(){

    this.router.navigate(['loading']);


  }

  onFileChange(fileChangeEvent) {
    this.file = fileChangeEvent.target.files[0];
  }
  onFile2Change(fileChangeEvent){
    this.file2 = fileChangeEvent.target.files[0];
  }

  async submitForm() {
    let formData = new FormData();
    formData.append("file[]", this.file, "images.jpg");
    formData.append("file[]",this.file2,"video.mp4");
    this.http.post("http://210.94.194.107:3001",
     formData).subscribe((response) => {

    });
    this.navigateToLoading();
     }

}


