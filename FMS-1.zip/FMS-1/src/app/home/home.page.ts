import { Component } from '@angular/core';
import { LoadingPage } from '../loading/loading.page';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {


  constructor(
    private router:Router
   ) {}

  navigateToLoading(){
    console.log("navigateToLoading");
    this.router.navigate(['loading'])
  }

 
  /**
   * name
  
  public name() {
    
  } readInputFile(e){
    var sel_files;
    $('#imagePreview').empty();
    
    var files = e.target.files;
    var fileArr = Array.prototype.slice.call(files);
    var index = 0;
    
    fileArr.forEach(function(f){
    	if(!f.type.match("image/.*")){
        	alert("upload image only");
            return;
      };
      else{
        	sel_files.push(f);
            var reader = new FileReader();
            reader.onload = function(e){
            	var html = `<a id=img_id_${index}><img src=${e.target.result} data-file=${f.name} /></a>`;
                $('imagePreview').append(html);
                index++;
            
      }
    }
    
  }
 */
 

}

