import { Component, OnInit } from '@angular/core';
import {NavController,NavParams, } from '@ionic/angular'

@Component({
  selector: 'app-loading',
  templateUrl: './loading.page.html',
  styleUrls: ['./loading.page.scss'],
})
export class LoadingPage implements OnInit {

  constructor() { }

  ngOnInit() {
    

  }

}
